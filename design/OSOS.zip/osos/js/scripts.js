$(window).load(function() {
      $('body').fadeIn('slow');
});